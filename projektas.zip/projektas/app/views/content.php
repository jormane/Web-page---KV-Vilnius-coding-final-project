

<div class="content-container">
            <div class="foto-title">
                <div class="col-md-12 col-sm-6 col-xs-12">
                    <img src="../app/images/erdveKV.jpg" alt="vidaus patalpos">
                </div>
            </div>
    
            <div class="title-text">
                <div class="col-md-12 col-sm-6 col-xs-12">
                    <br>
                    <h2>Švęskite savo šventes jaukioje ir erdvioje švenčių studijoje ŠIAULIUOSE!</h2>
                    <h3>Nepamirštami įspūdžiai - GARANTUOTI!</h3>
                    <br>
                </div>
            </div>   
            
    <div class="title-section">
      <div class="content-section">
          <div class="col-md-12 col-sm-12 col-xs-12">
                <section>
                    <h1>Studiją galime pritaikyti įvairiausioms <br> Jūsų progoms:</h1>
                        <p><i class="far fa-check-square" area-hidden="true"></i> Vaikų ir suaugusiųjų gimtadieniams;</p>
                        <p><i class="far fa-check-square" area-hidden="true"></i> Krikštynoms;</p>
                        <p><i class="far fa-check-square" area-hidden="true"></i> Įvairiems renginiams.</p>
                         
                            <a href ="http://localhost/php/projektas/public/kontaktai.php" method="post">
                                <span id="myBtn" class="btn btn-siusti">
                                    <span class="top content"><i class="fas fa-globe" area-hidden="true"></i>Bendraukime!</span>
                                    <span class="bottom content">Dabar!</span>
                                </span>
                            </a> 
                        <div style="clear:both;"></div>
                </section>
          </div>
        </div>
    </div>
    
        
<div class="slideshow-container" style="padding: 20px"> <!-- slider pradžia -->
        <div class="col-md-12 col-sm-12 hidden-xs">
            <div class="mySlides fade">
                <div class="numbertext">1 / 3</div>
                <img src="../app/images/foto004.jpg" alt="vidaus patalpos" style="width:100%">
                <div class="text">Žaidimų erdvė</div>
            </div>
            <div class="mySlides fade">
                <div class="numbertext">2 / 3</div>
                <img src="../app/images/erdvekiemo.jpg" alt="vidaus patalpos erdve" style="width:100%">
                <div class="text">Žaidimų erdvė</div>
            </div>
            <div class="mySlides fade">
                <div class="numbertext">3 / 3</div>
                <img src="../app/images/stalasKV.jpg" alt="papuostas stalas patalpu erdveje" style="width:100%">
                <div class="text">Dekoracijos</div>
            </div>
          <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
          <a class="next" onclick="plusSlides(1)">&#10095;</a>
        
        
    </div>
    <br>
        <div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
        </div>
</div>
    <!-- slider pabaiga -->
                    
    
</div>
    
                 
 