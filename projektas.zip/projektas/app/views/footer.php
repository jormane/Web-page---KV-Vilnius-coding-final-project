  <footer> 
      
    <div class="footer-container">
        
            <div class="footer-nav">
                <div class="col-md-12 col-sm-8 col-xs-12">
                    <ul class="list-unstyled">
                            <li><a href="https://www.facebook.com/kiemovaikai/"><i class="fab fa-facebook-square" area-hidden="true"></i>Facebook</a></li>
                            <li><a href="mailto:mbkiemovaikai@gmail.com"><i class="fas fa-envelope" area-hidden="true"></i>El. paštas</a></li>
                            <li><a href="+37062269517"><i class="fas fa-phone-square-alt" area-hidden="true"></i>+37062269517</a></li>
                            <li><a id ="googlemap" class="googlemap" href="https://www.google.com/maps/place/Au%C5%A1ros+al.+68A,+%C5%A0iauliai+76233/@55.939333,23.3050761,17z/data=!4m13!1m7!3m6!1s0x46e5e318388d6659:0x20b67b6c3b7c9b75!2sAu%C5%A1ros+al.+68A,+%C5%A0iauliai+76233!3b1!8m2!3d55.93933!4d23.3072649!3m4!1s0x46e5e318388d6659:0x20b67b6c3b7c9b75!8m2!3d55.93933!4d23.3072649" target ="googlemap" title="Rodyti žemėlapyje adresą" rel="nofollow"><i class="fas fa-map-marked-alt" area-hidden="true"></i>KIEMO VAIKAI, Aušros al. 68 (2 aukštas), Šiauliai</a></li>
                    </ul>
                    <div style="clear:both;"></div>
                </div>
            </div>
            
            <div class="metai">
                <div class="col-md-12 col-sm-4 col-xs-6">
                <?php 
           function metai($laikas){
            $designVC = 'Sukurta VC. Visos teisės saugomos.';
                if($laikas>=date('Y')) {
                        echo '&copy' . date ('Y') . ' ' . $designVC;
                } else {
                        echo '&copy' . $laikas . '-' . date('Y') . ' ' . $designVC;
                }
           } 
                metai(2020);

                ?>

                </div>
            </div>  
    </div>
   
</footer>   
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="../app/bootstrap/bootstrap-3.3.7-dist/js/bootstrap.js"></script>
<script src="../app/scripts/custom.js"></script>

</body>
</html>
