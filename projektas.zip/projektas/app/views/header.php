
<!-- JSON-LD žymėjimas, generuojamas „Google“ struktūrinių duomenų žymeklio. -->
<script type="application/ld+json">
{
  "@context" : "http://schema.org",
  "@type" : "LocalBusiness",
  "name" : "KIEMO VAIKAI",
  "image" : "http://www.googleusercontent.com/app/images/logo.png",
  "telephone" : "+37062269517",
  "email" : "mbkiemovaikai@gmail.com",
  "address" : {
    "@type" : "PostalAddress",
    "streetAddress" : "Aušros al. 68 (2 aukštas)",
    "addressLocality" : "Šiauliai"
  },
  "url" : "https://www.facebook.com/kiemovaikai/",
  "review" : {
    "@type" : "Review",
    "reviewBody" : "Švęskite savo šventes jaukioje ir erdvioje švenčių studijoje ŠIAULIUOSE!"
  }
}
</script>

<!DOCTYPE html>


<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Švenčių studija Šiauliuose - Kiemo vaikai</title>
    <link rel="stylesheet" href="../app/bootstrap/bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../app/fontawesome-free-5.12.0/css/fontawesome.min.css">
    <link rel="stylesheet" href="../app/fontawesome-free-5.12.0/css/all.css">
     <link href="https://fonts.googleapis.com/css?family=Love+Ya+Like+A+Sister&display=swap" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Asap&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../app/css/style.css">

</head>
    
<body>
 
<header> 
    
    <div class="header-container">
        
            <div class="top-header"> 
                
                <div class="header-contact">
                    <div class="col-md-12 col-sm-10 hidden-xs">
                        <ul class="list-unstyled">
                            <li><a href="https://www.facebook.com/kiemovaikai/"><i class="fab fa-facebook-square" area-hidden="true"></i>Facebook</a></li>
                            <li><a href="mailto:mbkiemovaikai@gmail.com"><i class="fas fa-envelope" area-hidden="true"></i>mbkiemovaikai@gmail.com</a></li>
                            <li><a href="+37062269517"><i class="fas fa-phone-square-alt" area-hidden="true"></i>+37062269517</a></li>
                            <li><a id ="googlemap" class="googlemap" href="https://www.google.com/maps/place/Au%C5%A1ros+al.+68A,+%C5%A0iauliai+76233/@55.939333,23.3050761,17z/data=!4m13!1m7!3m6!1s0x46e5e318388d6659:0x20b67b6c3b7c9b75!2sAu%C5%A1ros+al.+68A,+%C5%A0iauliai+76233!3b1!8m2!3d55.93933!4d23.3072649!3m4!1s0x46e5e318388d6659:0x20b67b6c3b7c9b75!8m2!3d55.93933!4d23.3072649" target ="googlemap" title="Rodyti žemėlapyje adresą" rel="nofollow"><i class="fas fa-map-marked-alt" area-hidden="true"></i>KIEMO VAIKAI, Aušros al. 68 (2 aukštas), Šiauliai</a></li>
                        </ul>
                    </div>
                    <div style="clear:both;"></div>
            
    
                </div>
            
        </div>
        
                <div class="header-nav">
                    <div class="col-md-3 col-sm-8 col-xs-12">
                        <a href="http://localhost/php/projektas/public/index.php">
                        <div class="logo">
                            <img src="../app/images/logo.png" alt="Logo" width="200" height="200">
                        </div>
                        </a>
                    </div>
                    
                    <div class="topnav" id="MyTopnav">
                                <a href="javascript:void(0)" class="icon" onclick="myFunction()"><i class="fa fa-bars"></i></a>
                                
                                    <ul class="list-unstyled">
                                        <li class="active"><a href="index.php">Pradinis</a></li>
                                        <li class="dropdown">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="index.php"> Apie mus<span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                            <li><a href="paslaugos.php">Paslaugos</a></li>
                                            <li><a href="akcijos.php">Akcijos</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="galerija.php">Galerija</a></li>
                                        <li><a href="idejos.php">Idėjos</a></li>
                                        <li><a href="kontaktai.php">Kontaktai</a></li>
                                        
                                    </ul>
                                     </div>
                                </div>
                            </div>   
                  



                
           
   
     
        
</header>