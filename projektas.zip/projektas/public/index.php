<?php
require __DIR__ . '/../app/src/app.php';
?>


<?php
include('../app/views/header.php');
?>
        


<?php
include('../app/views/content.php');
    ?>


<?php
include('../app/views/footer.php');
?>



    


