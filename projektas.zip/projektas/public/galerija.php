<?php
require __DIR__ . '/../app/src/app.php';
?>

<!--  image gallery script pradzia-->       
<script> 
let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("demo");
  let captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
} 
    
</script>

<!--  image gallery script pabaiga -->


<?php
include('../app/views/header.php');
?>
        


<div class="galerija-atidarymas">
       <div class="galerija-atidarymas-text">
           <div class="col-md-12 col-sm-12 col-xs-12">
                <h2><i class="far fa-star"></i> Didžiausia vaikų švenčių studija Šiauliuose kviečia rezervuoti laiką savo svarbiausioms šventėms! <i class="far fa-star"></i></h2>
                <h3><i class="far fa-star"></i>Nepamirštami įspūdžiai, daugybė veiklos ir geras laikas garantuotas<i class="far fa-star"></i></h3>
            <br>
           
                <form action ="http://localhost/php/projektas/public/kontaktai.php" method="post"> 
                    <button class="galerija-btn"> <i class="fas fa-angle-double-right"></i> <i class="fas fa-angle-double-right"></i> Bendraukime! </button>
                </form>
            </div>
        </div>
       
        <div class="galerija-atidarymas-foto"> 
            <div class="col-md-12 col-sm-10 col-xs-8">
                <p>KIEMO VAIKAI atidarymo šventės foto akimirkos:</p>               
            </div>
        </div>
                     
        <div class="container-gallery"> <!--  image gallery -->
            <div class="col-md-12 col-sm-10 col-xs-12">

            <div class="mySlides">
                <div class="numbertext">1 / 6</div>
                    <img src="../app/images/001galerija.jpg" alt="rodykles">
            </div>

            <div class="mySlides">
                <div class="numbertext">2 / 6</div>
                    <img src="../app/images/002galerija.jpg" alt="dekoracijos ant stalo">
            </div>

            <div class="mySlides">
                <div class="numbertext">3 / 6</div>
                    <img src="../app/images/003galerija.jpg" alt="berniukas laipioja ant sienos">
            </div>

            <div class="mySlides">
                <div class="numbertext">4 / 6</div>
                    <img src="../app/images/004galerija.jpg" alt="berniukas delioja kaladeles">
            </div>

            <div class="mySlides">
                <div class="numbertext">5 / 6</div>
                    <img src="../app/images/005galerija.jpg" alt="mergaite groja bugnais">
            </div>

            <div class="mySlides">
                <div class="numbertext">6 / 6</div>
                    <img src="../app/images/006galerija.jpg" alt="mergaite zaidzia su lelemis">
            </div>

            <div class="mySlides">
                <div class="numbertext">7 / 7</div>
                    <img src="../app/images/007galerija.jpg" alt="zaidimu erdve su zmonemis">
            </div>
    
            <div class="mySlides">
                <div class="numbertext">8 / 8</div>
                    <img src="../app/images/008galerija.jpg" alt="vaikai zaidzia kamuoliuku baseine">
            </div>
    
            <div class="mySlides">
                <div class="numbertext">9 / 9</div>
                    <img src="../app/images/009galerija.jpg" alt="berniukas ziuri pro ziuronus">
            </div>
    
            <div class="mySlides">
                <div class="numbertext">10 / 10</div>
                    <img src="../app/images/010galerija.jpg" alt="vaikai vaziuoja su traktoriumi">
            </div>
    
  
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>

            <div class="caption-container">
                <p id="caption"></p>
            </div>

                <div class="row">
                    <div class="column">
                        <img class="demo cursor" src="../app/images/001galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(1)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/002galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(2)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/003galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(3)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/004galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(4)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/005galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(5)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/006galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(6)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/007galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(7)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/008galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(8)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/009galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(9)">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="../app/images/010galerija.jpg" alt="KIEMO VAIKAI atidarymo šventės foto akimirkos" onclick="currentSlide(10)">
                    </div>
                </div>
            </div> 
         
        </div> 
         
<?php
include('../app/views/footer.php');
?>
