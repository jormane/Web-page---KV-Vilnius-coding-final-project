
    <?php
include('../app/views/header.php');
    ?>


<div class="idejos-container">  
     
        <div class="idejos-container-aprasymas">
            <div class="idejos-tortas-img">
                <div class="col-md-12 hidden-sm hidden-xs">
                    <img src="../app/images/foto002.jpg" alt="papuostas stalas sventei" width="auto" height="400">
                    <img src="../app/images/tortas.jpg" alt="tortas" width="auto" height="400">
                    <img src="../app/images/fotosiena2.jpg" alt="dekoruotas stalas" width="auto" height="400">
                </div> 
            </div>
            <div class="idejos-tortas-text">
                <div class="col-md-12 col-sm-12 col-xs-10">
                    <h3> <i class="fas fa-birthday-cake"></i> Kaip suplanuoti vaiko gimtadienį? </h3>
                    <h3><i class="fas fa-baby-carriage"></i> Kaip pasiruošti krikštynų šventei?</h3>
                    <h2> Apie tai ir dar daugiau jau NETRUKUS! </h2>
                </div> 
            </div>
        </div>
        
        <div class="idejos-container-btn-contact">
            <div class="col-md-12 col-sm-12 col-xs-8">
                <h4> Bendraukime! </h4> 
                <form action ="http://localhost/php/projektas/public/kontaktai.php" method="post"> 
                <button class="idejos-btn"> <i class="fas fa-angle-double-right"></i> <i class="fas fa-angle-double-right"></i> ČIA! </button>
                </form> 
            </div> 
        </div>
    
            <div style="clear:both;"></div>
        
        <div class="idejos-foto">
            <div class="col-md-12 hidden-sm hidden-xs">
                    <img src="../app/images/galerija01.jpg" alt="mergaite supasi" width="auto" height="300">
                    <img src="../app/images/stalasKV.jpg" alt="stalas su gelemis" width="auto" height="300">
                    <img src="../app/images/zaidimai01.jpg" alt="vaikai zaidzia" width="auto" height="300">
                    <div style="clear:both;"></div>
            </div>
        </div> 
    
        <div class="idejos-footer-foto">
            <div class="col-md-12 col-sm-12 col-xs-12">
                    <img src="../app/images/erdveKV.jpg" alt="kiemo vaikai patalpu erdve" width="auto" height="200">
            </div>
        </div>
    
</div>

<?php
include('../app/views/footer.php');
?>

