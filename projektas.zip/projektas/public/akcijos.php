
    <?php
include('../app/views/header.php');
    ?>




    <div class="akcijos-container">  
        <div class="akcijos-container-aprasymas">
            <div class="col-md-12 col-sm-10 col-xs-10">
           <h2> <i class="far fa-sun"></i>  Didžiausia vaikų švenčių studija Šiauliuose! <i class="far fa-sun"></i> </h2>
                <br> 
            <h3><i class="fas fa-exclamation"></i> Vasario mėnesį dar turime keletą laisvų vietų rezervacijai, tad paskubėkite <i class="fas fa-exclamation"></i> </h3>
                <br>
                <br> 

            <div class="akcijos-container-btn-contact">
                <h3> Užsakymai priimami </h3> 
                <form action ="http://localhost/php/projektas/public/kontaktai.php" method="post"> 
                    <button class="akcijos-btn"> <i class="fas fa-angle-double-right"></i> <i class="fas fa-angle-double-right"></i> ČIA </button>
                </form> 
            </div>
            </div>
        </div>
    
<div style="clear:both;"></div>
        
            <div class="akcijos-foto">
                <div class="col-md-12 col-sm-8 col-xs-10">
                    <img src="../app/images/girltractor.jpg" alt="Mergaite su traktoriumi" width="auto" height="250">
                    <div style="clear:both;"></div>
                </div>
            </div>
 </div>  
    



<?php
include('../app/views/footer.php');
?>
