
<?php
require __DIR__ . '/../app/src/app.php';
?>

<?php
include('../app/views/header.php');
?>
    
<div class="kontaktai-container">  
            
            <div class="tituline">
                <div class="col-md-12 col-sm-12 hidden-xs">
                    <img src="../app/images/VRKV.jpg" alt="berniukas su VR akiniais" width="auto" height="300">
                    <div style="clear:both;"></div>
                </div>
            </div>
    
            <div class="form"> 
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <form id="contact" action="kontaktai.php" method="post">   
                        <h3>Bendraukime</h3>
                        <h4>Susisiekite su mumis šiandien!</h4>
                                
                        <p><input type="text" name="vardas" placeholder="Jūsų vardas" required autofocus></p>
                        <p><input type="email" name="email" placeholder="Jūsų el. pašto adresas" required></p>
                        <p><input type="phone" name="phone" placeholder="Jūsų telefono numeris" required></p>
                        <p><textarea placeholder="Jūsų žinutė..." name="message" required></textarea></p>
                        <p><button name="submit" type="submit" id="contact-submit">Siųsti</button></p>
                    </form> 
                    <div style="clear:both;"></div>
                </div>
            </div>
    

    
</div>   

<?php
include('../app/views/footer.php');
?>