<?php
require __DIR__ . '/../app/src/app.php';
?>


<?php
include('../app/views/header.php');
?>
        
        
<div class="paslaugos-content">
        <div class="paslaugos-studio">
            <div class="col-md-12 col-sm-4 col-xs-10">
                <img src="../app/images/foto004.jpg" alt="Patalpu bendra erdve" width="auto" height="300">
                <div class="col-md-12 col-sm-10 col-xs-12">
                <h2>JŪSŲ PATOGUMUI STUDIJOJE ĮRENGTA:<br></h2>
                <p> <i class="far fa-check-square" area-hidden="true"></i> Vaikiški staliukai;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> 3 mediniai edukaciniai namukai, kuriuose daugybė žaislų;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> Aktyvi zona – alpinizmo ir gimnastikos sienelės, pusiausvyros takelis, čiuožykla, kamuoliukų baseinas, šokliukai;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> Virtualios realybės zona – Playstation VR akiniai;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> TV – jubiliato foto / video peržiūroms;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> Garso aparatūra;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> Kūdikių pervystymo stalas / sofutė kūdikio pamaitinimui; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Visi reikalingi serviravimo indai, įrankiai;<br>
                    <i class="far fa-check-square" area-hidden="true"></i> Kavos aparatas, virdulys.<br>
                </p>
                </div>
            </div> 
        </div>
        
        <div class="paslaugos-rupinames"> 
            <div class="col-md-12 col-sm-4 col-xs-12">
                <img src="../app/images/img07.jpg" alt="Sventes stalas" width="auto" height="300">
            
                <h2> JŪSŲ PATOGUMUI ŠVENTĖS METU GALIME PASIRŪPINTI:</h2> <br>
                <p> <i class="far fa-check-square" area-hidden="true"></i> Jubiliato vardo girlianda; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Vaišių zonos paruošimu – maistu pasirūpina patys užsakovai arba galime pasiūlyti iš savo tiekėjų; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Teminiu „Kiemo vaikai“ šventės dekoru arba kitu dekoru pagal Jūsų pasirinktą temą; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Balionais; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Animatoriumi; <br>
                    <i class="far fa-check-square" area-hidden="true"></i> Fotografu. <br>
                </p>
            </div> 
        </div>
        
        <div class="paslaugos-container-btn-contact">
            <div class="col-md-12 col-sm-4 col-xs-12">
                <h3> Užsakymai priimami </h3> 
                <form action ="http://localhost/php/projektas/public/kontaktai.php" method="post"> 
                    <button class="paslaugos-btn"> <i class="fas fa-angle-double-right"></i> <i class="fas fa-angle-double-right"></i> ČIA </button>
                </form> 
            </div>
        </div>
</div>

<?php
include('../app/views/footer.php');
?>
